# Change Log
`0.1.3`

- Added config entry to allow you to limit the maximum number of ghouls that can be summoned
- Removed item displays for ghoul equipment. I will come back to this and add item displays for the elite equipment later.

`0.1.2`

- Readme update lol

`0.1.1`

- Added SFX attribution to readme
- Added known issues section to readme

- For those wondering about ghoul ragdolls spazzing out, I found this to be an incompatibility with CustomEmoteAPI, which should have been fixed with the latest version of that mod. If you are still encountering this issue and you do not use CustomEmoteAPI, please let me know.

- Removed Deputy's entries from the config ~~how did I even miss this~~

- Fixed issue where Shovel Strike would fail to fire at high attack speed
- Shovel Strike's hitbox can now be angled up and down</br>
>The hitbox used to launch your minions _cannot_ be angled. Lemme know if you think it should be.</br>
>The swing animation has not yet been changed to reflect this but I'll get to it

- Ghouls now properly inherit your equipment
- Proc coefficient of ghouls' bite attack when clinging to large enemies reduced: *1 &rarr; 0.8*

- Tombstone now stuns when launched
- Tombstone launch velocity when hit by shovel reduced: *70 &rarr; 60*
- Tombstone vengeful soul launch range increased: *40m &rarr; 80m*
- Tombstone vengeful soul explosion radius increased: *10m &rarr; 15m* 
>Tombstone felt really underwhelming so I turned it into a proper artillery cannon. I'm still undecided on whether or not I should rework it completely, though.

`0.1.0`

- Initial release
